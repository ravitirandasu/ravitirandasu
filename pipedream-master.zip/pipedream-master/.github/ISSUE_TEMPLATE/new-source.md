---
name: New Source
about: Need to run a workflow on a specific event, like every time a new PR is opened
  on Github? Request it here!
title: "[TRIGGER]"
labels: enhancement
assignees: ''

---

**Describe the event source. What app, what event?**

**Please provide a link to the relevant API docs for the specific service / operation this trigger is tied to.**
