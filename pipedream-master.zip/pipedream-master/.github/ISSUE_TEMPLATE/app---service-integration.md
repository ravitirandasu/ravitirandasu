---
name: App / Integration Request
about: Request for a new API integration
title: "[APP]"
labels: app, enhancement
assignees: ''

---

**Name of app / service**

**Link to developer documentation**

**Is lack of support preventing you from building workflows, or do you have a workaround?**

**Are there specific actions, or triggers, you'd like to see for this app? Please let us know here or use the Action and Trigger issue templates to open requests for each!**
