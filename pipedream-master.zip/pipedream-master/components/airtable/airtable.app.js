module.exports = {
  type: "app",
  app: "airtable",
}
